import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';


@Component({
  selector: 'app-overdue',
  templateUrl: './overdue.component.html',
  styleUrls: ['./overdue.component.scss']
})
export class OverdueComponent implements OnInit {

  users

  constructor(private httpClient: HttpClient) { }

  ngOnInit() {

    this.httpClient.get("https://jsonplaceholder.typicode.com/posts").subscribe(
      (data) => {
        this.users = data;
        console.log("this.sadfdfdf", this.users);
      },
      err => console.log("err", err))


  }

}
